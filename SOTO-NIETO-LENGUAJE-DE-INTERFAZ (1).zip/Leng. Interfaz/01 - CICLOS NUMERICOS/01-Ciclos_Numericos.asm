; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)



INCLUDE Irvine32.inc

.data

mensaje BYTE "Hola mundo", 0   ;Mensaje a imprimir

.code

main PROC

    mov ecx, 1                  ; Cantidad de veces a imprimir el mensaje 
    mod edx, OFFSET mensaje     ; Byte inicial del mensaje a imprimir

    ciclo:                      ; Ciclo para imprimir el mensaje 

        call WriteString        ; Usa el OFFSET para imprimir el mensaje desde el BYTE inicial del mensaje
        call Crlf               ; Realiza un salto de linea entre cada mensaje impreso
        loop ciclo              ; fincion de Irvine32 para ciclar 

        exit                    ; Termina el codigo y lo cierra 

main ENDP
END main