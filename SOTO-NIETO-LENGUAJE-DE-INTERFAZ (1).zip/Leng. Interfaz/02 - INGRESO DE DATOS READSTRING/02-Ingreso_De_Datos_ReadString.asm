; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)


INCLUDE Irvine32.inc

.data

mensajeEntrada BYTE "Escribe tu nombre: ", 0            ; Se le pide al usuario ingresar su nombre
nombre BYTE 10 DUP(0)                                   ; Crea una reserva de BYTES para que el ususario escriba su nombre
caracteresEscritos BYTE "Numero de caracteres: ", 0     ; Se muestra para la cantidad de numeros de caracteres leidos en el nombre


.data

main PROC

    mov edx, OFFSET mensajeEntrada          ; Guarda en "edx" la direccion del mensaje de entrada
    call WriteString                        ; Muestra el mensaje en pantalla
    mov edx, OFFSET nombre                  ; Guarda en EDX el espacio para la direccion del nombre
    mov ecx , SIZEOF nombre                 ; Indica el espacio maximo de carracteres

    call ReadString                         ; Lee el nombre y devuelve su longitud

    mov edx, OFFSET nombre                  ; Guarda en EDX la direccion del espacio del nombre
    call WriteString                        ; Muestra el nombre ingresado
    call Crlf                               ; Salto de linea

    mov edx, OFFSET caracterEscrito         ; Guarda en EDX la direccion del mensaje 
    call WriteString                        ; Muestra el mensaje 
    call WriteDec                           ; Muestra la longitud del mensaje 
    call Crlf                               ; Salto de lines
    
    exit                                    ; Fin del programa

main ENDP
END main
