; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)

INCLUDE Irvine32.inc

.data

main PROC

    ; Caso 1: ZF

    mov eax, 10h            ; Ingresa el valor a compar

    cmp eax, 10h            ; Compara los valores directamente
    call DumpRegs           ; muestra las banderas para comprobar si es igual

    ; Caso 2: SF

    mov eax, 0              ; limpia el registro EAX
    mov ebx, 0              ; limpria el registro EBX

    mov al, -5              ; Asigna un valor en Al
    mov bl, 1               ; Asigna un valor en Bl
    cmp al, bl              ; Compara los valores directamente 
    call DumpRegs           ; Muestra las banderas despues de la comparacion

    ; Caso 3: Carry Flag

    mov aex, 0              ; limpa registro
    mov ebx, 0              ; limpia registro

    mov al, 5               ; asigna valor
    mov bl, 10              ; asigna valor

    cmp al, bl              ; compara 
    call DumpRegs           ; banderas

    ; Caso 4: OVERFLOW

    mov aex, 0              ; limpia registros
    mov ebx, 0   

    mov al, -128            ; asigna valor
    mov bl, 1               ; asigna un valor

    cmp al, bl              ; Realiza la comparacion
    call DumpRegs           ; Muestra banderas

    ; Caso 5: TEST

    mov eax, 0              ; limpia registro
    mov eax, 5              ; Asigna valor
    test eax, 1             ; comprueva si el valor es igual
    call DumpRegs           ; muestra banderas 

    mov eax, 0              ; Limpia registro
    mov eax, 10000000b      ; Asignamos un valos en binario
    test eax, 10000000b     ; comparamos en binarios
    call DumpRegs           ; llama banderas 

exit

main END
END main


