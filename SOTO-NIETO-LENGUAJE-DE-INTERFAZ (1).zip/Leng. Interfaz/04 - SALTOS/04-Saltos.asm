; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)


INCLUDE Irvine32.inc

.data
    msgNoDebe BYTE "Este mensaje no debe mostrarse",0 ; Mensaje que se omite
    msgJmp BYTE "Salto incondicional realizado",0 ; Mensaje de salto
    msgIgual BYTE "EAX y EBX son iguales",0 ; Mensaje de igualdad
    msgDistinto BYTE "EAX y EBX son distintos",0 ; Mensaje de diferencia
    msgMayor BYTE "EAX es mayor que EBX",0 ; Mensaje si es mayor
    msgMenor BYTE "EAX no es mayor que EBX",0 ; Mensaje si no es mayor
    msgBajo BYTE "EAX es menor que EBX",0 ; Mensaje si es menor sin signo
    msgNoBajo BYTE "EAX no es menor que EBX",0 ; Mensaje si no es menor sin signo

.code
main PROC
    ; Salto incondicional
    jmp saltoIncondicional ; Salta directamente a la etiqueta

    mov edx, OFFSET msgNoDebe ; Direccion del mensaje omitido
    call WriteString ; Muestra el mensaje
    call Crlf ; Salta una linea

saltoIncondicional:
    mov edx, OFFSET msgJmp ; Direccion del mensaje
    call WriteString ; Muestra el mensaje
    call Crlf ; Salta una linea

    ; Comprobar si los valores son iguales
    mov eax, 10 ; Guarda el primer valor
    mov ebx, 10 ; Guarda el segundo valor
    cmp eax, ebx ; Compara ambos valores
    je iguales ; Salta si son iguales
    mov edx, OFFSET msgDistinto ; Direccion del mensaje de diferencia
    jmp mostrarIgualdad ; Salta a mostrar el resultado

iguales:
    mov edx, OFFSET msgIgual ; Direccion del mensaje de igualdad

mostrarIgualdad:
    call WriteString ; Muestra el resultado
    call Crlf ; Salta una linea

    ; Comprobar si EAX es mayor que EBX con signo
    mov eax, 10 ; Guarda el primer valor
    mov ebx, 5 ; Guarda el segundo valor
    cmp eax, ebx ; Compara ambos valores
    jg mayor ; Salta si EAX es mayor
    mov edx, OFFSET msgMenor ; Direccion del mensaje si no es mayor
    jmp mostrarSigned ; Salta a mostrar el resultado

mayor:
    mov edx, OFFSET msgMayor ; Direccion del mensaje si es mayor

mostrarSigned:
    call WriteString ; Muestra el resultado
    call Crlf ; Salta una linea

    ; Comprobar si EAX es menor que EBX sin signo
    mov eax, 5 ; Guarda el primer valor
    mov ebx, 10 ; Guarda el segundo valor
    cmp eax, ebx ; Compara ambos valores
    jb menorSinSigno ; Salta si EAX es menor sin signo
    mov edx, OFFSET msgNoBajo ; Direccion del mensaje si no es menor
    jmp mostrarUnsigned ; Salta a mostrar el resultado

menorSinSigno:
    mov edx, OFFSET msgBajo ; Direccion del mensaje si es menor

mostrarUnsigned:
    call WriteString ; Muestra el resultado
    call Crlf ; Salta una linea

    exit ; Finaliza el programa
main ENDP
END main