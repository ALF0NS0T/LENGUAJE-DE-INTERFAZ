; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)

INCLUDE Irvine32.inc

.code
main PROC

    mov ebx, 1              ; Valor inicial del contador

ciclo:
    cmp eax, 100             ; Compara EAX con 100
    jg ciclo2                ; Salta si EAX es mayor que 100
    call WriteDec            ; Muestra el valor de EAX
    call Crlf                ; Salto de línea

    inc eax                  ; Aumenta EAX en 1
    jmp ciclo                ; Regresa al ciclo

ciclo2:
    mov eax, ebx             ; Copia EBX en EAX
    call WriteDec            ; Muestra el valor de EBX
    call Crlf                ; Salto de línea

    mov eax, 1               ; Reinicia EAX en 1
    cmp ebx, 100              ; Compara EBX con 100
    jg fin                   ; Salta si EBX es mayor que 100

    inc ebx                  ; Aumenta EBX en 1
    jmp ciclo                ; Regresa al ciclo

fin:
    exit                     ; Termina el programa

main ENDP
END main