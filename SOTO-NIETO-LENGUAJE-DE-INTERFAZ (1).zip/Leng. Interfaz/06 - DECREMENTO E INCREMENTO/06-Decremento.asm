; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)

INCLUDE Irvine32.inc

.data
msgPIN BYTE "Ingrese el PIN de acceso: ", 0         ; Mensaje para pedir el PIN
msgError BYTE "***PIN INCORRECTO***", 0              ; Mensaje de error
msgAcceso BYTE "ACCESO PERMITIDO.", 0                ; Mensaje de acceso correcto
msgIntentos BYTE "Intentos restantes: ", 0           ; Mensaje de intentos disponibles
msgBloqueo BYTE "**** Sistema bloqueado por exceso de intentos ****", 0 ; Mensaje de bloqueo

pinCorrecto = 1234    ; Valor correcto del PIN

.code
main PROC
    mov ebx, 3                 ; Guarda los 3 intentos disponibles

inicio:
    mov edx, OFFSET msgPIN     ; Dirección del mensaje
    call WriteString           ; Solicita el PIN
    call ReadInt               ; Lee el PIN ingresado
    call Crlf                  ; Salto de línea
    cmp eax, pinCorrecto       ; Compara el PIN ingresado

    je acceso                  ; Salta si el PIN es correcto

    dec ebx                    ; Resta un intento
    mov edx, OFFSET msgError   ; Dirección del mensaje de error
    call WriteString           ; Muestra el error
    call Crlf                  ; Salto de línea

    mov edx, OFFSET msgIntentos ; Dirección del mensaje
    call WriteString            ; Muestra los intentos restantes
    mov eax, ebx                ; Copia los intentos en EAX
    call WriteDec               ; Muestra los intentos
    call Crlf                   ; Salto de línea

    cmp ebx, 0                 ; Comprueba si no quedan intentos
    je bloqueo                 ; Salta si se agotaron
    jmp inicio                 ; Vuelve a pedir el PIN

acceso:
    mov edx, OFFSET msgAcceso  ; Dirección del mensaje de acceso
    call WriteString           ; Muestra el acceso permitido
    call Crlf                  ; Salto de línea
    exit                       ; Termina el programa

bloqueo:
    mov edx, OFFSET msgBloqueo ; Dirección del mensaje de bloqueo
    call WriteString           ; Muestra el bloqueo
    call Crlf                  ; Salto de línea
    exit                       ; Termina el programa

main ENDP
END main