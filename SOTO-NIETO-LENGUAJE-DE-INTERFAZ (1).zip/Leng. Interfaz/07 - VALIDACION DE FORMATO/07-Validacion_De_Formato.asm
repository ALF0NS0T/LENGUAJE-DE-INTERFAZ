; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)


INCLUDE Irvine32.inc

.data
    mensaje BYTE "Ingrese el codigo: ",0 ; Mensaje de entrada
    valido BYTE "Formato valido",0      ; Mensaje de éxito
    invalido BYTE "Formato invalido",0   ; Mensaje de error

    cadena BYTE 20 DUP(0)                ; Espacio para el código

.code
main PROC

    ; Pedir el texto
    mov edx, OFFSET mensaje              ; Dirección del mensaje
    call WriteString                     ; Muestra el mensaje

    ; Leer el texto
    mov edx, OFFSET cadena               ; Dirección de la cadena
    mov ecx, 19                          ; Máximo de caracteres
    call ReadString                      ; Lee el código

    ; Comprobar longitud
    cmp eax, 7                           ; Verifica 7 caracteres
    jne fallo                            ; Salta si es diferente

    ; Posición 0: A-Z
    mov al, cadena[0]                    ; Lee el primer carácter
    cmp al, 'A'                          ; Compara con A
    jb fallo                             ; Salta si es menor
    cmp al, 'Z'                          ; Compara con Z
    ja fallo                             ; Salta si es mayor

    ; Posición 1: A-Z
    mov al, cadena[1]                    ; Lee el segundo carácter
    cmp al, 'A'                          ; Compara con A
    jb fallo                             ; Salta si es menor
    cmp al, 'Z'                          ; Compara con Z
    ja fallo                             ; Salta si es mayor

    ; Posición 2: A-Z
    mov al, cadena[2]                    ; Lee el tercer carácter
    cmp al, 'A'                          ; Compara con A
    jb fallo                             ; Salta si es menor
    cmp al, 'Z'                          ; Compara con Z
    ja fallo                             ; Salta si es mayor

    ; Posición 3: guion
    mov al, cadena[3]                    ; Lee el cuarto carácter
    cmp al, '-'                          ; Verifica el guion
    jne fallo                            ; Salta si es diferente

    ; Posición 4: 0-9
    mov al, cadena[4]                    ; Lee el quinto carácter
    cmp al, '0'                          ; Compara con 0
    jb fallo                             ; Salta si es menor
    cmp al, '9'                          ; Compara con 9
    ja fallo                             ; Salta si es mayor

    ; Posición 5: 0-9
    mov al, cadena[5]                    ; Lee el sexto carácter
    cmp al, '0'                          ; Compara con 0
    jb fallo                             ; Salta si es menor
    cmp al, '9'                          ; Compara con 9
    ja fallo                             ; Salta si es mayor

    ; Posición 6: 0-9
    mov al, cadena[6]                    ; Lee el séptimo carácter
    cmp al, '0'                          ; Compara con 0
    jb fallo                             ; Salta si es menor
    cmp al, '9'                          ; Compara con 9
    ja fallo                             ; Salta si es mayor

    ; Código correcto
    mov edx, OFFSET valido               ; Dirección del mensaje
    call WriteString                     ; Muestra el éxito
    jmp salir                            ; Salta al final

fallo:
    mov edx, OFFSET invalido             ; Dirección del mensaje
    call WriteString                     ; Muestra el error

salir:
    call Crlf                            ; Salto de línea
    exit                                 ; Termina el programa

main ENDP
END main