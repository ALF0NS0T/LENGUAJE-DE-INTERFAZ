; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)

INCLUDE Irvine32.inc

.code
main PROC

    ; 1. ADD y SUB: Suma y resta
    mov eax, 50       ; Guarda el valor 50
    mov ebx, 20       ; Guarda el valor 20

    add eax, ebx      ; Suma EAX y EBX
    sub eax, 15       ; Resta 15 al resultado

    nop               ; No realiza ninguna operación

    ; 2. CF: Acarreo en suma sin signo
    mov eax, 0        ; Limpia EAX
    mov al, 255       ; Guarda 255 en AL

    add al, 1         ; Suma 1 y genera acarreo

    ; 3. OF: Desbordamiento con signo
    mov eax, 0        ; Limpia EAX
    mov al, 127       ; Guarda el máximo positivo de AL

    add al, 1         ; Genera desbordamiento con signo

    nop               ; No realiza ninguna operación

    ; 4. MUL: Multiplicación sin signo
    mov eax, 65532    ; Guarda el primer valor
    mov ebx, 65532    ; Guarda el segundo valor

    mul ebx           ; Multiplica EAX por EBX

    ; IMUL: Multiplicación con signo
    mov eax, -5       ; Guarda el valor -5

    imul eax, eax, 3  ; Multiplica -5 por 3

    nop               ; No realiza ninguna operación

    ; 5. DIV: División sin signo
    mov eax, 125      ; Guarda el dividendo
    mov edx, 0        ; Limpia la parte alta del dividendo
    mov ebx, 12       ; Guarda el divisor

    div ebx           ; Divide EDX:EAX entre EBX

    nop               ; No realiza ninguna operación

    ; 6. IDIV y CDQ: División con signo
    mov eax, -125     ; Guarda el dividendo negativo
    cdq               ; Extiende el signo de EAX a EDX

    mov ebx, 12       ; Guarda el divisor
    idiv ebx          ; Divide con signo: -125 entre 12

    nop               ; No realiza ninguna operación

    exit              ; Finaliza el programa

main ENDP
END main