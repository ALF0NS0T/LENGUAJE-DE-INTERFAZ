; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)

INCLUDE Irvine32.inc

.data
mensaje BYTE "Hola, mundo!", 0    ; Mensaje de texto

.code
main PROC
    ; Bloque 1: PUSH y POP
    mov eax, 40       ; Guarda el valor 40
    push eax          ; Guarda EAX en la pila

    nop               ; No realiza ninguna operación
    mov eax, 0        ; Limpia EAX
    pop ebx           ; Recupera el valor de la pila en EBX
    nop               ; No realiza ninguna operación

    ; Bloque 2: Orden LIFO
    mov eax, 10       ; Guarda el valor 10
    push eax          ; Guarda 10 en la pila

    mov eax, 20       ; Guarda el valor 20
    push eax          ; Guarda 20 en la pila

    mov eax, 30       ; Guarda el valor 30
    push eax          ; Guarda 30 en la pila

    nop               ; No realiza ninguna operación

    pop eax           ; Recupera 30 en EAX
    pop ebx           ; Recupera 20 en EBX
    pop ecx           ; Recupera 10 en ECX

    nop               ; No realiza ninguna operación

    ; Bloque 3: Conservar registros
    mov eax, 100      ; Guarda el valor 100
    mov ebx, 200      ; Guarda el valor 200

    push eax          ; Guarda EAX en la pila
    push ebx          ; Guarda EBX en la pila

    mov eax, 999      ; Modifica EAX
    mov ebx, 666      ; Modifica EBX

    pop ebx           ; Recupera el valor original de EBX
    pop eax           ; Recupera el valor original de EAX

    nop               ; No realiza ninguna operación

    ; Bloque 4: CALL y RET
    mov eax, 50       ; Guarda el valor 50
    mov ebx, 100      ; Guarda el valor 100

    call aumentarDiez ; Llama al procedimiento

    nop               ; No realiza ninguna operación

    exit              ; Finaliza el programa
main ENDP

aumentarDiez PROC
    push ebx          ; Guarda el valor original de EBX
    mov ebx, 10       ; Guarda el valor 10
    add eax, ebx      ; Suma 10 a EAX
    pop ebx           ; Restaura el valor original de EBX
    ret               ; Regresa al programa principal
aumentarDiez ENDP

END main