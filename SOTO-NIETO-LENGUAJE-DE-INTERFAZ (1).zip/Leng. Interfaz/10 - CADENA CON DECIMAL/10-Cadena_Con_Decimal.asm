; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)

INCLUDE Irvine32.inc

.data
    tamanoArchivo DWORD 100000 ; Tamaño total del archivo
    bloquesRecibidos DWORD 125 ; Bloques recibidos
    tamanoBloque DWORD 512 ; Tamaño de cada bloque

    bytesDescargados DWORD 0 ; Total de bytes descargados
    bytesPendientes DWORD 0 ; Bytes que faltan descargar
    porcentajeAvance DWORD 0 ; Porcentaje de avance
    gruposCompletos DWORD 0 ; Grupos completos de 1024 bytes
    residuoGrupos DWORD 0 ; Bytes restantes del agrupamiento

    buffer BYTE 11 DUP(0) ; Espacio para la cadena numerica

    msgDescargados BYTE "Bytes descargados: ",0 ; Mensaje de descargados
    msgPendientes BYTE "Bytes pendientes: ",0 ; Mensaje de pendientes
    msgPorcentaje BYTE "Porcentaje de avance: ",0 ; Mensaje de porcentaje
    msgGrupos BYTE "Grupos completos de 1024 bytes: ",0 ; Mensaje de grupos
    msgResiduo BYTE "Residuo del agrupamiento: ",0 ; Mensaje del residuo

.code
main PROC
    ; Calcular los bytes descargados
    mov eax, bloquesRecibidos ; Carga los bloques recibidos
    mul tamanoBloque ; Multiplica por el tamaño del bloque
    mov bytesDescargados, eax ; Guarda los bytes descargados

    ; Calcular los bytes pendientes
    mov ebx, tamanoArchivo ; Carga el tamaño del archivo
    sub ebx, eax ; Resta los bytes descargados
    mov bytesPendientes, ebx ; Guarda los bytes pendientes

    ; Calcular el porcentaje de avance
    mov eax, bytesDescargados ; Carga los bytes descargados
    mov ebx, 100 ; Carga el valor para calcular el porcentaje
    mul ebx ; Multiplica los bytes por 100
    div tamanoArchivo ; Divide entre el tamaño del archivo
    mov porcentajeAvance, eax ; Guarda el porcentaje

    ; Calcular los grupos de 1024 bytes
    mov eax, bytesDescargados ; Carga los bytes descargados
    mov edx, 0 ; Limpia la parte alta de la division
    mov ebx, 1024 ; Tamaño de cada grupo
    div ebx ; Divide y obtiene cociente y residuo
    mov gruposCompletos, eax ; Guarda los grupos completos
    mov residuoGrupos, edx ; Guarda los bytes sobrantes

    ; Mostrar los resultados
    mov eax, bytesDescargados ; Carga los bytes descargados
    mov edx, OFFSET msgDescargados ; Direccion del mensaje
    call mostrarNumero ; Muestra el mensaje y el numero

    mov eax, bytesPendientes ; Carga los bytes pendientes
    mov edx, OFFSET msgPendientes ; Direccion del mensaje
    call mostrarNumero ; Muestra el mensaje y el numero

    mov eax, porcentajeAvance ; Carga el porcentaje
    mov edx, OFFSET msgPorcentaje ; Direccion del mensaje
    call mostrarNumero ; Muestra el mensaje y el numero

    mov eax, gruposCompletos ; Carga los grupos completos
    mov edx, OFFSET msgGrupos ; Direccion del mensaje
    call mostrarNumero ; Muestra el mensaje y el numero

    mov eax, residuoGrupos ; Carga el residuo
    mov edx, OFFSET msgResiduo ; Direccion del mensaje
    call mostrarNumero ; Muestra el mensaje y el numero

    exit ; Finaliza el programa
main ENDP

; Muestra el mensaje y el numero convertido a cadena
mostrarNumero PROC
    push eax ; Guarda el numero
    call WriteString ; Muestra el mensaje
    pop eax ; Recupera el numero

    mov esi, OFFSET buffer ; Direccion del buffer
    call convertirDecimal ; Convierte el numero a texto

    mov edx, OFFSET buffer ; Direccion de la cadena
    call WriteString ; Muestra el numero convertido
    call Crlf ; Salta a la siguiente linea
    ret ; Regresa al programa principal
mostrarNumero ENDP

; Convierte el numero de EAX a texto decimal
convertirDecimal PROC
    push eax ; Guarda EAX
    push ebx ; Guarda EBX
    push ecx ; Guarda ECX
    push edx ; Guarda EDX
    push esi ; Guarda ESI

    mov ebx, 10 ; Divisor para obtener digitos decimales
    mov ecx, 0 ; Inicializa el contador de digitos

extraerDigitos:
    mov edx, 0 ; Limpia EDX antes de dividir
    div ebx ; Divide entre 10
    push edx ; Guarda el digito obtenido en la pila
    inc ecx ; Cuenta el digito
    cmp eax, 0 ; Comprueba si quedan digitos
    jne extraerDigitos ; Repite mientras queden digitos

construirCadena:
    pop edx ; Recupera un digito
    add dl, '0' ; Convierte el digito a caracter ASCII
    mov [esi], dl ; Guarda el caracter en el buffer
    inc esi ; Avanza a la siguiente posicion
    loop construirCadena ; Repite hasta copiar todos los digitos

    mov BYTE PTR [esi], 0 ; Agrega el terminador de cadena

    pop esi ; Restaura ESI
    pop edx ; Restaura EDX
    pop ecx ; Restaura ECX
    pop ebx ; Restaura EBX
    pop eax ; Restaura EAX
    ret ; Regresa al procedimiento anterior
convertirDecimal ENDP

END main