; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)

INCLUDE Irvine32.inc

; ESTADOS DE LA COMPUTADORA
; 0 = Computadora encendida
; 1 = Alarma
; 2 = Computadora conectada

.data
alarmaEncendidaMsg BYTE "Alarma esta encendida", 0 ; Mensaje de alarma activa
alarmaApagadaMsg BYTE "Alarma esta apagada", 0     ; Mensaje de alarma inactiva
msg1 BYTE "AND", 0                                 ; Nombre de la operación AND
msg2 BYTE "OR", 0                                  ; Nombre de la operación OR
msg3 BYTE "XOR", 0                                 ; Nombre de la operación XOR
msg4 BYTE "TEST", 0                                ; Nombre de la operación TEST

.code
main PROC

    ; 1. AND: Evaluar alarma
    mov edx, OFFSET msg1        ; Dirección del mensaje
    call WriteString            ; Muestra AND
    call Crlf                   ; Salto de línea
    mov eax, 0                  ; Limpia EAX
    mov al, 00000101b           ; Estado inicial
    and al, 00000010b            ; Comprueba el bit de alarma
    call WriteBin               ; Muestra el resultado binario
    call Crlf                   ; Salto de línea

    ; 2. OR: Encender alarma
    mov edx, OFFSET msg2        ; Dirección del mensaje
    call WriteString            ; Muestra OR
    call Crlf                   ; Salto de línea
    mov eax, 0                  ; Limpia EAX
    mov al, 00000101b           ; Estado inicial
    or al, 00000010b             ; Activa el bit de alarma
    call WriteBin               ; Muestra el resultado binario
    call Crlf                   ; Salto de línea

    ; 3. XOR: Cambiar estado de la computadora
    mov edx, OFFSET msg3        ; Dirección del mensaje
    call WriteString            ; Muestra XOR
    call Crlf                   ; Salto de línea
    mov eax, 0                  ; Limpia EAX
    mov al, 00000101b           ; Estado inicial
    xor al, 00000001b            ; Cambia el bit de encendido
    call WriteBin               ; Muestra el nuevo estado
    call Crlf                   ; Salto de línea
    xor al, 00000001b            ; Cambia el bit nuevamente
    call WriteBin               ; Muestra el estado restaurado
    call Crlf                   ; Salto de línea

    ; 4. TEST: Comprobar estado de la alarma
    mov edx, OFFSET msg4        ; Dirección del mensaje
    call WriteString            ; Muestra TEST
    call Crlf                   ; Salto de línea
    mov eax, 0                  ; Limpia EAX
    mov al, 00000101b           ; Estado inicial
    test al, 00000010b           ; Comprueba el bit de alarma
    call WriteBin               ; Muestra AL en binario
    call Crlf                   ; Salto de línea
    test al, 00000010b           ; Comprueba si la alarma está activa
    jne alarmaEncendida         ; Salta si el bit está activado
    jmp alarmaApagada           ; Salta si el bit está apagado

alarmaEncendida:
    mov edx, OFFSET alarmaEncendidaMsg ; Dirección del mensaje
    call WriteString                   ; Muestra alarma encendida
    call Crlf                          ; Salto de línea
    jmp fin                            ; Salta al final

alarmaApagada:
    mov edx, OFFSET alarmaApagadaMsg   ; Dirección del mensaje
    call WriteString                   ; Muestra alarma apagada
    call Crlf                          ; Salto de línea
    jmp fin                            ; Salta al final

fin:
    exit                               ; Termina el programa

main ENDP
END main