; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)

INCLUDE Irvine32.inc

.data 
mensajeRolls BYTE "------------------ SECCION DE ROR, ROL, RCR, RCL ------------------", 0

.code 
main PROC
    mov eax, 0
    mov ebx, 0
    mov ecx, 0
    mov edx, 0

    ; 1. SHL: Desplaza bits a la izquierda
    mov al, 10000110b       ; Guarda el valor binario
    shl al, 1               ; Desplaza un bit a la izquierda
    call DumpRegs           ; Muestra los registros y banderas
    call WriteBin           ; Muestra el valor binario
    call Crlf               ; Salto de línea

    ; 2. SHR: Desplaza bits a la derecha
    mov al, 00001101b       ; Guarda el valor binario
    shr al, 1               ; Desplaza un bit a la derecha
    call DumpRegs           ; Muestra los registros y banderas
    call WriteBin           ; Muestra el valor binario
    call Crlf               ; Salto de línea

    ; 3. SAR: Desplazamiento con signo
    mov eax, 0              ; Limpia EAX
    mov al, -8              ; Guarda el valor -8
    sar al, 1               ; Desplaza conservando el signo
    call DumpRegs           ; Muestra los registros y banderas
    call WriteBin           ; Muestra el valor binario
    call Crlf               ; Salto de línea

    ; 4. SAR: Desplazamiento de un impar negativo
    mov eax, 0              ; Limpia EAX
    mov al, -9              ; Guarda el valor -9
    sar al, 1               ; Desplaza conservando el signo
    call DumpRegs           ; Muestra los registros y banderas
    call WriteBin           ; Muestra el valor binario
    call Crlf               ; Salto de línea

    ; 5. Conteo constante: Desplaza dos posiciones
    mov al, 00001100b       ; Guarda el valor 12
    shl al, 2               ; Desplaza dos bits a la izquierda
    call DumpRegs           ; Muestra los registros y banderas
    call WriteBin           ; Muestra el valor binario
    call Crlf               ; Salto de línea

    ; 6. Conteo con CL: Desplaza usando un registro
    mov al, 00001100b       ; Guarda el valor 12
    mov cl, 2               ; Define dos desplazamientos
    shr al, cl              ; Desplaza dos bits a la derecha
    call DumpRegs           ; Muestra los registros y banderas
    call WriteBin           ; Muestra el valor binario
    call Crlf               ; Salto de línea

        ; 7. ROR, ROL, RCR y RCL: Rotaciones de bits
    mov edx, OFFSET mensajeRolls ; Dirección del mensaje
    call WriteString             ; Muestra el título
    call Crlf                    ; Salto de línea

    clc                          ; Limpia la bandera de acarreo
    mov eax, 0                   ; Limpia EAX
    mov al, 10000001b            ; Guarda el valor binario

    ; ROR: Rota los bits a la derecha
    ror al, 1                    ; Rota un bit a la derecha
    call DumpRegs                ; Muestra registros y banderas
    call WriteBin                ; Muestra el valor binario
    call Crlf                    ; Salto de línea

    ; ROL: Rota los bits a la izquierda
    rol al, 1                    ; Rota un bit a la izquierda
    call DumpRegs                ; Muestra registros y banderas
    call WriteBin                ; Muestra el valor binario
    call Crlf                    ; Salto de línea

    ; RCR: Rota a la derecha usando el acarreo
    rcr al, 1                    ; Rota un bit a la derecha pasando por CF
    call DumpRegs                ; Muestra registros y banderas
    call WriteBin                ; Muestra el valor binario
    call Crlf                    ; Salto de línea

    ; RCL: Rota a la izquierda usando el acarreo
    rcl al, 1                    ; Rota un bit a la izquierda pasando por CF
    call DumpRegs                ; Muestra registros y banderas
    call WriteBin                ; Muestra el valor binario
    call Crlf                    ; Salto de línea

    exit                    ; Termina el programa
main ENDP
END main