; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)


INCLUDE Irvine32.inc

.data
    valor DWORD 12AB34CDh ; Numero que se va a convertir
    bufferHex BYTE 9 DUP(0) ; Espacio para 8 digitos hexadecimales
    msgHex BYTE "Valor en hexadecimal: ",0 ; Mensaje del resultado

.code
main PROC
    mov eax, valor ; Carga el numero en EAX
    mov esi, 7 ; Posicion inicial de la cadena
    mov ecx, 8 ; Cantidad de digitos hexadecimales

ciclo:
    mov ebx, eax ; Copia el numero
    and ebx, 0Fh ; Obtiene los 4 bits menos significativos

    cmp ebx, 10 ; Comprueba si el digito es menor que 10
    jb esDigito ; Salta si el digito esta entre 0 y 9
    sub ebx, 10 ; Ajusta el valor entre 10 y 15
    add ebx, 'A' ; Convierte el valor en letra A-F
    jmp guardar ; Salta a guardar el caracter

esDigito:
    add ebx, '0' ; Convierte el valor en caracter 0-9

guardar:
    mov bufferHex[esi], bl ; Guarda el caracter en la cadena
    shr eax, 4 ; Desplaza el numero 4 bits a la derecha
    dec esi ; Retrocede una posicion
    loop ciclo ; Repite para los 8 digitos

    mov bufferHex[8], 0 ; Agrega el terminador de cadena

    mov edx, OFFSET msgHex ; Direccion del mensaje
    call WriteString ; Muestra el mensaje
    mov edx, OFFSET bufferHex ; Direccion del resultado
    call WriteString ; Muestra el numero hexadecimal
    call Crlf ; Salta una linea

    exit ; Finaliza el programa
main ENDP
END main