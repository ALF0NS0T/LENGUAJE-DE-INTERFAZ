; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)


INCLUDE Irvine32.inc

.data
    mensaje BYTE "Cantidad de tarjetas ESP32 recibidas (1-99): ",0 ; Mensaje de entrada
    errorMsg BYTE "Cantidad invalida. Intente nuevamente.",0 ; Mensaje de error
    resultado BYTE "Existencia actual: ",0 ; Mensaje del resultado
    unidades BYTE " unidades",0 ; Texto de unidades

    entrada BYTE 10 DUP(0) ; Guarda la entrada del usuario
    bufferNumero BYTE 11 DUP(0) ; Guarda el numero convertido a texto
    temporal BYTE 10 DUP(0) ; Guarda temporalmente los digitos

    cantidadRecibida DWORD 0 ; Cantidad de tarjetas recibidas
    existenciaInicial DWORD 25 ; Existencia inicial de tarjetas
    existenciaActual DWORD 0 ; Existencia despues de sumar
    longitud DWORD 0 ; Longitud de la entrada

.code
main PROC

leerCantidad:
    mov edx, OFFSET mensaje ; Direccion del mensaje
    call WriteString ; Muestra el mensaje

    mov edx, OFFSET entrada ; Direccion de la entrada
    mov ecx, SIZEOF entrada - 1 ; Limite de caracteres
    call ReadString ; Lee la cantidad ingresada

    mov longitud, eax ; Guarda la longitud ingresada

    ; Validar que tenga uno o dos caracteres
    cmp eax, 1 ; Compara la longitud con 1
    jl cantidadInvalida ; Si es menor, marca error
    cmp eax, 2 ; Compara la longitud con 2
    jg cantidadInvalida ; Si es mayor, marca error

    ; Validar que todos sean digitos
    mov esi, OFFSET entrada ; Direccion del texto
    mov ecx, longitud ; Numero de caracteres por revisar

validarDigitos:
    mov al, [esi] ; Obtiene un caracter
    cmp al, '0' ; Compara con el digito 0
    jb cantidadInvalida ; Si es menor, marca error
    cmp al, '9' ; Compara con el digito 9
    ja cantidadInvalida ; Si es mayor, marca error

    inc esi ; Avanza al siguiente caracter
    loop validarDigitos ; Repite hasta revisar todos

    ; Convertir el primer digito
    mov esi, OFFSET entrada ; Direccion de la entrada
    movzx eax, BYTE PTR [esi] ; Obtiene el primer digito
    sub eax, '0' ; Convierte el caracter a numero

    ; Si tiene un digito, ya esta convertido
    cmp longitud, 1 ; Comprueba si tiene un digito
    je validarRango ; Si tiene uno, valida el rango

    ; Convertir el segundo digito
    imul eax, 10 ; Multiplica el primer digito por 10
    movzx ebx, BYTE PTR [esi+1] ; Obtiene el segundo digito
    sub ebx, '0' ; Convierte el caracter a numero
    add eax, ebx ; Forma el numero completo

validarRango:
    ; Aceptar solamente cantidades de 1 a 99
    cmp eax, 1 ; Compara con el minimo permitido
    jl cantidadInvalida ; Si es menor, marca error
    cmp eax, 99 ; Compara con el maximo permitido
    jg cantidadInvalida ; Si es mayor, marca error

    ; Guardar la cantidad recibida
    mov cantidadRecibida, eax ; Guarda la cantidad

    ; Sumar a la existencia inicial
    mov eax, existenciaInicial ; Carga la existencia inicial
    add eax, cantidadRecibida ; Suma las tarjetas recibidas
    mov existenciaActual, eax ; Guarda la nueva existencia

    ; Mostrar el resultado
    mov edx, OFFSET resultado ; Direccion del mensaje
    call WriteString ; Muestra el mensaje

    mov eax, existenciaActual ; Carga la existencia actual
    call ConvertirDecimal ; Convierte el numero a texto

    mov edx, OFFSET bufferNumero ; Direccion del numero convertido
    call WriteString ; Muestra la existencia actual

    mov edx, OFFSET unidades ; Direccion del texto de unidades
    call WriteString ; Muestra las unidades
    call Crlf ; Salta a la siguiente linea

    exit ; Finaliza el programa

cantidadInvalida:
    mov edx, OFFSET errorMsg ; Direccion del mensaje de error
    call WriteString ; Muestra el error
    call Crlf ; Salta a la siguiente linea
    jmp leerCantidad ; Solicita la cantidad nuevamente

main ENDP

; Convierte el numero de EAX a una cadena decimal.
; El resultado queda en bufferNumero.
ConvertirDecimal PROC
    push eax ; Guarda EAX
    push ebx ; Guarda EBX
    push ecx ; Guarda ECX
    push edx ; Guarda EDX
    push esi ; Guarda ESI
    push edi ; Guarda EDI

    mov ebx, 10 ; Divisor para obtener digitos
    mov esi, OFFSET temporal ; Direccion del almacenamiento temporal
    xor ecx, ecx ; Inicializa el contador

    ; Caso especial: numero cero
    cmp eax, 0 ; Comprueba si el numero es cero
    jne dividirNumero ; Si no es cero, comienza la division

    mov BYTE PTR [esi], '0' ; Guarda el caracter cero
    inc esi ; Avanza una posicion
    inc ecx ; Cuenta el digito guardado
    jmp copiarNumero ; Pasa a copiar el resultado

dividirNumero:
    xor edx, edx ; Limpia EDX antes de dividir
    div ebx ; Divide EDX:EAX entre 10

    add dl, '0' ; Convierte el residuo en caracter
    mov [esi], dl ; Guarda el digito temporalmente
    inc esi ; Avanza una posicion
    inc ecx ; Cuenta el digito guardado

    cmp eax, 0 ; Comprueba si quedan digitos
    jne dividirNumero ; Repite mientras queden digitos

    ; Invertir los digitos
copiarNumero:
    dec esi ; Apunta al ultimo digito guardado
    mov edi, OFFSET bufferNumero ; Direccion del resultado

copiarDigito:
    mov al, [esi] ; Obtiene un digito
    mov [edi], al ; Copia el digito al resultado
    inc edi ; Avanza en el resultado
    dec esi ; Retrocede al digito anterior
    loop copiarDigito ; Repite hasta copiar todos

    mov BYTE PTR [edi], 0 ; Agrega el terminador nulo

    pop edi ; Restaura EDI
    pop esi ; Restaura ESI
    pop edx ; Restaura EDX
    pop ecx ; Restaura ECX
    pop ebx ; Restaura EBX
    pop eax ; Restaura EAX

    ret ; Regresa al programa principal
ConvertirDecimal ENDP

END main