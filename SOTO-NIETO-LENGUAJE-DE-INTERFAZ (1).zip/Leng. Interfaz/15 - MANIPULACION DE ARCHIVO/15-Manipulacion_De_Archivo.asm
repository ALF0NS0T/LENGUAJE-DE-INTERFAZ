; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)


INCLUDE Irvine32.inc

.data
nombreArchivo BYTE "Inventario.txt", 0     ; Nombre del archivo
texto BYTE "125", 0                         ; Texto que se guardará
archivoHandle DWORD ?                       ; Guarda el identificador del archivo

mensajeExito BYTE "Archivo guardado correctamente", 0 ; Mensaje de éxito
mensajeError BYTE "No se pudo guardar el archivo", 0  ; Mensaje de error

.code
main PROC

    ; 1. Crear archivo TXT
    mov edx, OFFSET nombreArchivo   ; Dirección del nombre
    call CreateOutputFile           ; Crea o abre el archivo

    cmp eax, INVALID_HANDLE_VALUE   ; Comprueba si hubo error
    je error                        ; Salta si no se pudo crear

    mov archivoHandle, eax          ; Guarda el identificador

    ; 2. Escribir texto en el archivo
    mov eax, archivoHandle           ; Identificador del archivo
    mov edx, OFFSET texto            ; Dirección del texto
    mov ecx, SIZEOF texto - 1        ; Cantidad de caracteres
    call WriteToFile                 ; Escribe el texto

    jc errorEscritura                ; Salta si ocurre un error

    cmp eax, SIZEOF texto - 1        ; Comprueba los bytes escritos
    jne errorEscritura               ; Salta si faltan caracteres

    ; 3. Cerrar el archivo
    mov eax, archivoHandle           ; Identificador del archivo
    call CloseFile                   ; Cierra el archivo

    test eax, eax                    ; Comprueba el resultado
    jz error                         ; Salta si falla el cierre

    mov edx, OFFSET mensajeExito     ; Dirección del mensaje
    call WriteString                 ; Muestra el éxito
    jmp fin                          ; Salta al final

errorEscritura:
    mov eax, archivoHandle           ; Identificador del archivo
    call CloseFile                   ; Cierra el archivo

error:
    mov edx, OFFSET mensajeError     ; Dirección del mensaje
    call WriteString                 ; Muestra el error
    call Crlf                        ; Salto de línea

fin:
    exit                             ; Finaliza el programa

main ENDP
END main