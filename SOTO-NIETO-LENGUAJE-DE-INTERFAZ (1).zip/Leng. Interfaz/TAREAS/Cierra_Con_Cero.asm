; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)

INCLUDE Irvine32.inc

.data
    mensaje BYTE "Ingresa un numero (0 para salir): ",0 ; Solicita un numero

.code
main PROC

ciclo:
    mov edx, OFFSET mensaje ; Direccion del mensaje
    call WriteString ; Muestra el mensaje
    call ReadInt ; Lee el numero ingresado

    cmp eax, 0 ; Compara el numero con cero
    je fin ; Si es cero, termina el programa

    call WriteDec ; Muestra el numero ingresado
    call Crlf ; Salta una linea
    jmp ciclo ; Repite el ciclo

fin:
    exit ; Finaliza el programa

main ENDP
END main