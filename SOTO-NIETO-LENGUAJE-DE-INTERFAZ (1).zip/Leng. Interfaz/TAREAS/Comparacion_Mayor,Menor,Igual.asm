; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)

INCLUDE Irvine32.inc
.data
mensajeNum1 BYTE "Ingrese el num1: ", 0     ; Mensaje para pedir el primer número
mensajeNum2 BYTE "Ingrese el num2: ", 0     ; Mensaje para pedir el segundo número
msgmayor BYTE "El num1 es mayor", 0          ; Mensaje si num1 es mayor
msgmenor BYTE "El num1 es menor", 0          ; Mensaje si num1 es menor
msgigual BYTE "Los numeros son iguales", 0   ; Mensaje si son iguales

num1 DWORD ?     ; Espacio para guardar el primer número
num2 DWORD ?     ; Espacio para guardar el segundo número

.code
main PROC
    mov edx, OFFSET mensajeNum1  ; Dirección del mensaje
    call WriteString             ; Muestra el mensaje

    call ReadInt                 ; Lee el primer número
    mov num1, eax                ; Guarda el valor ingresado
    call Crlf                    ; Salto de línea

    mov edx, OFFSET mensajeNum2  ; Dirección del mensaje
    call WriteString             ; Muestra el mensaje

    call ReadInt                 ; Lee el segundo número
    mov num2, eax                ; Guarda el valor ingresado
    call Crlf                    ; Salto de línea

    mov eax, num1                ; Carga el primer número
    mov ebx, num2                ; Carga el segundo número

    cmp eax, ebx                 ; Compara ambos números

    jg mayor                     ; Salta si num1 es mayor
    jl menor                     ; Salta si num1 es menor
    je igual                     ; Salta si son iguales

mayor:
    mov edx, OFFSET msgmayor     ; Dirección del mensaje
    call WriteString             ; Muestra que num1 es mayor
    jmp fin                      ; Salta al final

menor:
    mov edx, OFFSET msgmenor     ; Dirección del mensaje
    call WriteString             ; Muestra que num1 es menor
    jmp fin                      ; Salta al final

igual:
    mov edx, OFFSET msgigual     ; Dirección del mensaje
    call WriteString             ; Muestra que son iguales
    jmp fin                      ; Salta al final

fin:
    call Crlf                    ; Salto de línea
    exit                         ; Termina el programa

main ENDP
END main