; LENGUAJE DE ITERFAZ
; SOTO NIETO JESÚS ALFONSO. num. 23170344 
; Horario: 10-11 
; Docente: JOSE LUIS MEDINA (mAIstro)


INCLUDE Irvine32.inc

.data
capacidad = 20 ; Capacidad maxima del estacionamiento

msgOp1      BYTE "1. Entra un carro",0 ; Opcion para entrar
msgOp2      BYTE "2. Sale un carro",0 ; Opcion para salir
msgOp3      BYTE "3. Salir",0 ; Opcion para terminar
msgOpcion   BYTE "Opcion: ",0 ; Solicita una opcion
msgLleno    BYTE "ESTACIONAMIENTO LLENO: no se permite entrar mas carros.",0 ; Mensaje de estacionamiento lleno
msgVacio    BYTE "ESTACIONAMIENTO VACIO.",0 ; Mensaje de estacionamiento vacio
msgCarros   BYTE "Carros dentro: ",0 ; Muestra la cantidad de carros

.code
main PROC
    mov ebx, 0 ; Inicializa la cantidad de carros en cero

menu:
    call Crlf ; Salta una linea
    mov edx, OFFSET msgOp1 ; Direccion de la opcion 1
    call WriteString ; Muestra la opcion 1
    call Crlf ; Salta una linea
    mov edx, OFFSET msgOp2 ; Direccion de la opcion 2
    call WriteString ; Muestra la opcion 2
    call Crlf ; Salta una linea
    mov edx, OFFSET msgOp3 ; Direccion de la opcion 3
    call WriteString ; Muestra la opcion 3
    call Crlf ; Salta una linea
    mov edx, OFFSET msgOpcion ; Direccion del mensaje de opcion
    call WriteString ; Solicita la opcion
    call ReadInt ; Lee la opcion ingresada

    cmp eax, 1 ; Compara con la opcion 1
    je entrada ; Si es 1, permite entrar
    cmp eax, 2 ; Compara con la opcion 2
    je salida ; Si es 2, permite salir
    cmp eax, 3 ; Compara con la opcion 3
    je fin ; Si es 3, termina el programa
    jmp menu ; Si no es valida, muestra el menu

entrada:
    cmp ebx, capacidad ; Comprueba si esta lleno
    jae lleno ; Si llego al limite, muestra el mensaje
    inc ebx ; Agrega un carro
    cmp ebx, capacidad ; Comprueba si acaba de llenarse
    jne mostrar ; Si no esta lleno, muestra la cantidad

lleno:
    mov edx, OFFSET msgLleno ; Direccion del mensaje de lleno
    call WriteString ; Muestra el mensaje
    call Crlf ; Salta una linea
    jmp mostrar ; Muestra la cantidad de carros

salida:
    cmp ebx, 0 ; Comprueba si esta vacio
    je vacio ; Si no hay carros, muestra el mensaje
    dec ebx ; Resta un carro
    jnz mostrar ; Si quedan carros, muestra la cantidad

vacio:
    mov edx, OFFSET msgVacio ; Direccion del mensaje de vacio
    call WriteString ; Muestra el mensaje
    call Crlf ; Salta una linea

mostrar:
    mov edx, OFFSET msgCarros ; Direccion del mensaje de cantidad
    call WriteString ; Muestra el mensaje
    mov eax, ebx ; Copia la cantidad de carros
    call WriteDec ; Muestra la cantidad en decimal
    call Crlf ; Salta una linea
    jmp menu ; Regresa al menu

fin:
    exit ; Finaliza el programa
main ENDP
END main